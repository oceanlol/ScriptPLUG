print("Universal script loaded!")
