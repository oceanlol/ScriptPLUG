print("Rivals script loaded!")
