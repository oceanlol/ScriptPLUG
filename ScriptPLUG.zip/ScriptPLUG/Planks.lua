print("Planks script loaded!")
