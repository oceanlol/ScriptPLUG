print("Arsenal script loaded!")
