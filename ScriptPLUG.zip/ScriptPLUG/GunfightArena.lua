print("Gunfight Arena script loaded!")
