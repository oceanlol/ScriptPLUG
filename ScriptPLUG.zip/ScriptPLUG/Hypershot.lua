print("Hypershot script loaded!")
