print("Counterblox script loaded!")
